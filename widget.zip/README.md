# widget
## requirements
node
grunt
bower

## init
'''
npm install
grunt watch // for compiler sass
